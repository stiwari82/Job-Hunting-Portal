package com.jobhunting.exception;

public class NotYetAppliedException extends RuntimeException{

	private static final long serialVersionUID = 1L;
	
	public NotYetAppliedException(String message) {
		super(message);
	}

}



